from django.db import models
# from django.db.models.deletion import CASCADE
from .category import Category

class Product(models.Model):
    name=models.CharField(max_length=20)
    price=models.IntegerField(default=0)
    category = models.ForeignKey(Category ,  on_delete=models.CASCADE , default=1) 
    desc=models.CharField(max_length=300,default='',null=True,blank=True)
    image=models.ImageField(upload_to='uploads/products/')

    # def __str__(self):
    #     return self.name
    @staticmethod
    def get_products_by_id(ids):#it can pass list in ids form cart page
        return Product.objects.filter(id__in= ids)#id__in is use for all list item are chick all sempli =ids it is list of over product
    @staticmethod
    def get_all_product():
        return Product.objects.all()
    @staticmethod
    def get_all_product_by_id(category_id):
        if category_id:
            return Product.objects.filter(category=category_id)
        else:
            return Product.get_all_product();