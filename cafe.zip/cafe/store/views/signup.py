from django.shortcuts import render,redirect
# from django.http import HttpResponse
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password 
from django.views import View


    
class Signup(View):
    def get(self , request):
        return render(request,'signup.html')
    def post(self , request):
        first_name=request.POST.get('firstname')
        last_name=request.POST.get('lastname')
        phone=request.POST.get('phone')
        email=request.POST.get('email')
        password=request.POST.get('password')
        print(first_name, last_name, phone, email, password)
        value ={
            'first_name':first_name,
            'last_name':last_name,
             'phone':phone,
             'email':email
        }
        
        customer = Customer(first_name=first_name , last_name=last_name, phone=phone, email=email, password=password)
        error_massage =self.validateCustomer(customer)

        if not error_massage:
            print(first_name,last_name,phone,email,password)
            # customer.password = make_password(customer.password)
            
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('homepage')#redirect use for diractliy exese over page
        else:
            data = {
                'error':error_massage,
                'values':value
                }
            return render(request , 'signup.html',data)
    def validateCustomer(self,customer):
    #   customer = Customer(first_name=first_name,last_name=last_name,phone=phone,email=email,password=password);
        error_massage=None;
        if(not customer.first_name):
            error_massage='First Name Required  !!!'
        elif len(customer.first_name) < 4: 
            error_massage='First Name must be 4 char long'
        elif not customer.last_name:
            error_massage='Last Name Required  !!!'
        elif len(customer.last_name) < 4:
            error_massage='Last Name must be 4 char long'
        elif not customer.phone:
            error_massage='Phone Number Required  !!!'
        elif len(customer.phone) < 10:
            error_massage='Phone Number must be 10'
        elif len(customer.email) <5 :
            error_massage='Email  Required  !!!'
        elif not customer. password:
            error_massage='Password must be Requied !!!'
        
        elif len(customer.password) <5:
            error_massage='Password  must be 6 char long'
        
        elif customer.isExists():
            error_massage='Email Address Alredy registered...'  
        return error_massage  
    

